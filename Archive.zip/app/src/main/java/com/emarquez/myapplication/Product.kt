package com.emarquez.myapplication

data class Product(val name: String,
                   val brand: String)